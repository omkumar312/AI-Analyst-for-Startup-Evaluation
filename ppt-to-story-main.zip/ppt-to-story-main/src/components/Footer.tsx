import { Github, Linkedin, Mail, Globe } from "lucide-react";
import aiIcon from "@/assets/ai-icon.png";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img src={aiIcon} alt="AI Analyst" className="w-8 h-8" />
              <span className="text-xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                AI Analyst
              </span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md">
              Revolutionary AI-powered platform for startup evaluation and investor matching. 
              Built by Team Synapse Hacker for the Google Cloud Hackathon.
            </p>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
              >
                <Github className="w-5 h-5 text-primary" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
              >
                <Linkedin className="w-5 h-5 text-primary" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center hover:bg-primary/20 transition-colors"
              >
                <Mail className="w-5 h-5 text-primary" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-card-foreground mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#problem" className="text-muted-foreground hover:text-primary transition-colors">Problem</a></li>
              <li><a href="#solution" className="text-muted-foreground hover:text-primary transition-colors">Solution</a></li>
              <li><a href="#features" className="text-muted-foreground hover:text-primary transition-colors">Features</a></li>
              <li><a href="#team" className="text-muted-foreground hover:text-primary transition-colors">Team</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-card-foreground mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" />
                <span className="text-sm">team@synapsehacker.dev</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <Globe className="w-4 h-4" />
                <span className="text-sm">Google Cloud Hackathon</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-muted-foreground text-sm">
              © 2024 Team Synapse Hacker. Built for Google Cloud H2S Exchange Hackathon.
            </p>
            <p className="text-muted-foreground text-sm">
              Prototype Submission - AI Analyst for Startup Evaluation
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;