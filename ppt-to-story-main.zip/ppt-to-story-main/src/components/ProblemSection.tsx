import { AlertTriangle, Clock, TrendingDown, Users } from "lucide-react";

const ProblemSection = () => {
  const problems = [
    {
      icon: Clock,
      title: "Time-Consuming Process",
      description: "Investors spend hours manually reviewing hundreds of pitch decks, slowing down decision-making."
    },
    {
      icon: TrendingDown,
      title: "Inconsistent Evaluation",
      description: "Current tools only check surface-level metrics like financials or formatting, missing business viability."
    },
    {
      icon: Users,
      title: "Biased Feedback",
      description: "Human bias affects startup evaluation, creating unfair advantages for some founders over others."
    },
    {
      icon: AlertTriangle,
      title: "Delayed Results",
      description: "Founders receive vague, delayed feedback that doesn't help them improve their pitch or strategy."
    }
  ];

  return (
    <section id="problem" className="py-20 bg-gradient-subtle">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            The Challenge We're Solving
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Current startup evaluations are time-consuming, biased, and inconsistent. 
            The ecosystem needs an intelligent, fair, and scalable solution.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {problems.map((problem, index) => (
            <div
              key={index}
              className="bg-card rounded-xl p-6 shadow-elegant hover:shadow-glow transition-all duration-300 border border-border group"
            >
              <div className="mb-4">
                <problem.icon className="w-12 h-12 text-primary group-hover:text-accent transition-colors" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-card-foreground">
                {problem.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {problem.description}
              </p>
            </div>
          ))}
        </div>

        {/* Impact Statement */}
        <div className="mt-16 text-center">
          <div className="bg-primary/10 rounded-2xl p-8 border border-primary/20">
            <h3 className="text-2xl font-bold text-primary mb-4">
              The Result: Broken Startup Ecosystem
            </h3>
            <p className="text-lg text-foreground max-w-4xl mx-auto">
              Without proper evaluation tools, promising startups fail to get funding, 
              while investors miss out on high-potential opportunities. Our AI solution 
              bridges this gap with intelligent, unbiased analysis.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;