import { Award, Users, Lightbulb, Target } from "lucide-react";

const TeamSection = () => {
  return (
    <section id="team" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Meet Team Synapse Hacker
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Innovation meets expertise. Our team combines AI technology with deep 
            understanding of the startup ecosystem to deliver game-changing solutions.
          </p>
        </div>

        {/* Team Leader Spotlight */}
        <div className="bg-gradient-primary rounded-2xl p-8 text-white text-center mb-16 shadow-elegant">
          <div className="bg-white/20 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <Users className="w-12 h-12 text-white" />
          </div>
          <h3 className="text-2xl font-bold mb-2">ARYAN KESHARI</h3>
          <p className="text-xl mb-4 text-white/90">Team Leader</p>
          <p className="text-white/80 max-w-2xl mx-auto leading-relaxed">
            Leading the charge in AI-driven startup evaluation, bringing together cutting-edge 
            technology and practical business insights to revolutionize the funding ecosystem.
          </p>
        </div>

        {/* Team Values */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="text-center group">
            <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
              <Lightbulb className="w-8 h-8 text-primary" />
            </div>
            <h4 className="text-lg font-semibold mb-2 text-foreground">Innovation</h4>
            <p className="text-muted-foreground">Pushing boundaries with AI technology</p>
          </div>
          
          <div className="text-center group">
            <div className="bg-accent/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
              <Target className="w-8 h-8 text-accent" />
            </div>
            <h4 className="text-lg font-semibold mb-2 text-foreground">Precision</h4>
            <p className="text-muted-foreground">Data-driven decision making</p>
          </div>
          
          <div className="text-center group">
            <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <h4 className="text-lg font-semibold mb-2 text-foreground">Collaboration</h4>
            <p className="text-muted-foreground">Bridging investors and founders</p>
          </div>
          
          <div className="text-center group">
            <div className="bg-accent/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 group-hover:bg-accent/20 transition-colors">
              <Award className="w-8 h-8 text-accent" />
            </div>
            <h4 className="text-lg font-semibold mb-2 text-foreground">Excellence</h4>
            <p className="text-muted-foreground">Delivering exceptional results</p>
          </div>
        </div>

        {/* Hackathon Context */}
        <div className="bg-card rounded-2xl p-8 border border-border">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4 text-card-foreground">
              Gen AI Google Cloud H2S Exchange Hackathon
            </h3>
            <p className="text-muted-foreground mb-6 max-w-3xl mx-auto">
              This prototype was developed for the Google Cloud Hackathon, showcasing our team's 
              ability to create innovative AI solutions that address real-world challenges in 
              the startup ecosystem.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-primary/5 rounded-lg p-4">
                <h4 className="font-semibold text-primary mb-2">Problem Identified</h4>
                <p className="text-sm text-muted-foreground">AI Analyst for Startup Evaluation</p>
              </div>
              <div className="bg-accent/5 rounded-lg p-4">
                <h4 className="font-semibold text-accent mb-2">Solution Delivered</h4>
                <p className="text-sm text-muted-foreground">Comprehensive AI-powered platform</p>
              </div>
              <div className="bg-primary/5 rounded-lg p-4">
                <h4 className="font-semibold text-primary mb-2">Technology Used</h4>
                <p className="text-sm text-muted-foreground">Vertex AI & Machine Learning</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TeamSection;