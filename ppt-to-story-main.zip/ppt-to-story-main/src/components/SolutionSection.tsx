import { Button } from "@/components/ui/button";
import { Brain, BarChart3, Users, FileText, ArrowRight } from "lucide-react";
import evaluationImage from "@/assets/evaluation-process.jpg";

const SolutionSection = () => {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Analysis",
      description: "Uses Vertex AI to understand pitch decks beyond surface-level metrics"
    },
    {
      icon: BarChart3,
      title: "SWOT & Predictive Scoring",
      description: "Comprehensive analysis with success probability prediction"
    },
    {
      icon: Users,
      title: "Investor Matching",
      description: "Heatmap-based fit scoring connects startups with right investors"
    },
    {
      icon: FileText,
      title: "Instant Reports",
      description: "Detailed insights delivered through dashboards and downloadable PDFs"
    }
  ];

  const steps = [
    "Founders upload pitch decks",
    "Backend stores and routes data", 
    "Vertex AI extracts insights",
    "ML models score viability",
    "Investors matched via heatmap",
    "Reports generated instantly"
  ];

  return (
    <section id="solution" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Our AI-Powered Solution
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Revolutionary evaluation engine that acts like a virtual venture analyst, 
            providing holistic startup assessment with predictive insights.
          </p>
        </div>

        {/* Key Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {features.map((feature, index) => (
            <div
              key={index}
              className="text-center group"
            >
              <div className="bg-gradient-primary rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-elegant group-hover:shadow-glow transition-all">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-foreground">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* How It Works */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold mb-6 text-foreground">
              How It Works
            </h3>
            <div className="space-y-4">
              {steps.map((step, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center font-semibold text-sm">
                    {index + 1}
                  </div>
                  <p className="text-foreground">{step}</p>
                </div>
              ))}
            </div>
            <Button variant="cta" className="mt-8 group">
              See Demo
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
          
          <div className="relative">
            <div className="bg-gradient-primary rounded-2xl p-1">
              <img
                src={evaluationImage}
                alt="AI Evaluation Process"
                className="w-full h-auto rounded-xl shadow-elegant"
              />
            </div>
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-accent text-accent-foreground rounded-full p-3 shadow-glow animate-bounce">
              <Brain className="w-6 h-6" />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-primary text-primary-foreground rounded-full p-3 shadow-elegant animate-pulse">
              <BarChart3 className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Value Proposition */}
        <div className="mt-20 bg-card rounded-2xl p-8 border border-border">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <h4 className="text-2xl font-bold text-primary mb-2">For Investors</h4>
              <p className="text-card-foreground">Faster decisions with data-driven insights</p>
            </div>
            <div>
              <h4 className="text-2xl font-bold text-accent mb-2">For Founders</h4>
              <p className="text-card-foreground">Smarter feedback to improve pitch quality</p>
            </div>
            <div>
              <h4 className="text-2xl font-bold text-primary mb-2">For Ecosystem</h4>
              <p className="text-card-foreground">Scalable, unbiased evaluation platform</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SolutionSection;