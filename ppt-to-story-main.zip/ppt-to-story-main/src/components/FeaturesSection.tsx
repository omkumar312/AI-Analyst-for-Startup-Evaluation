import { Target, Zap, Shield, TrendingUp, Database, Users2 } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: Target,
      title: "Holistic Evaluation",
      description: "Goes beyond financials to analyze team strength, market potential, product innovation, and competitive positioning.",
      gradient: "from-primary to-primary-glow"
    },
    {
      icon: Zap,
      title: "Predictive Analytics",
      description: "Uses machine learning to estimate funding probability and provide data-driven success predictions.",
      gradient: "from-accent to-accent-glow"
    },
    {
      icon: Shield,
      title: "Bias-Free Scoring",
      description: "Eliminates human bias, creating fair evaluations for underrepresented founders and diverse teams.",
      gradient: "from-primary to-accent"
    },
    {
      icon: TrendingUp,
      title: "Real-Time Insights",
      description: "Instant analysis with actionable recommendations to improve pitch quality and funding chances.",
      gradient: "from-accent to-primary"
    },
    {
      icon: Database,
      title: "Comprehensive Reports",
      description: "Detailed SWOT analysis, risk assessments, and downloadable PDF reports for stakeholders.",
      gradient: "from-primary-glow to-accent-glow"
    },
    {
      icon: Users2,
      title: "Smart Matching",
      description: "AI-powered investor matching based on persona, preferences, and investment thesis alignment.",
      gradient: "from-accent-glow to-primary"
    }
  ];

  const differentiators = [
    "Acts like a virtual venture analyst, not just a summarizer",
    "Eliminates bias for fair evaluation of all founders",
    "Provides predictive funding probability scores",
    "Matches startups to investors intelligently"
  ];

  return (
    <section id="features" className="py-20 bg-gradient-subtle">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
            Key Features & Innovation
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our AI platform delivers comprehensive startup evaluation with features 
            that transform how investors and founders approach the funding process.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-card rounded-xl p-6 shadow-elegant hover:shadow-glow transition-all duration-300 border border-border group hover:scale-105"
            >
              <div className={`bg-gradient-to-r ${feature.gradient} rounded-full w-14 h-14 flex items-center justify-center mb-4 shadow-elegant`}>
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-card-foreground">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Differentiators */}
        <div className="bg-primary/5 rounded-2xl p-8 border border-primary/10">
          <h3 className="text-3xl font-bold text-center mb-8 text-foreground">
            What Makes Us Different
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {differentiators.map((diff, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="bg-gradient-primary rounded-full w-6 h-6 flex items-center justify-center mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <p className="text-foreground font-medium">{diff}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Technology Stack */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold mb-8 text-foreground">
            Powered by Advanced AI Technology
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-70">
            <div className="bg-card rounded-lg px-6 py-3 border border-border">
              <span className="font-semibold text-primary">Vertex AI</span>
            </div>
            <div className="bg-card rounded-lg px-6 py-3 border border-border">
              <span className="font-semibold text-primary">Machine Learning</span>
            </div>
            <div className="bg-card rounded-lg px-6 py-3 border border-border">
              <span className="font-semibold text-primary">Natural Language Processing</span>
            </div>
            <div className="bg-card rounded-lg px-6 py-3 border border-border">
              <span className="font-semibold text-primary">Predictive Analytics</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;